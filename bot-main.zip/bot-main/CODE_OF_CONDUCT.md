# Code of Conduct

The Python Discord Code of Conduct can be found [on our website](https://pydis.com/coc).
