**Voice verification**

Can’t talk in voice chat? Check out <#764802555427029012> to get access. The criteria for verifying are specified there.
