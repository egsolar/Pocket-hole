import logging

from bot.log import get_logger

log = get_logger()
log.setLevel(logging.CRITICAL)
